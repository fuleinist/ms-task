// import React from 'react';
// import { expect } from 'chai';
// import { mount } from 'enzyme';
// import { Provider } from 'react-redux';
// import { createStore, combineReducers } from 'redux';
// import { routerReducer } from 'react-router-redux';
// import rootReducer from 'redux/reducers/RootReducer';
// import {
//   validatorRequired,
//   validatorAlphaNumeric,
// } from 'supports/Common/Common.support';
// import { LocalForm } from 'react-redux-form';
// import MSFormInput from 'components/Ui/MSFormInput/MSFormInput';

// const store = createStore(
//   combineReducers({
//     app: rootReducer,
//     routing: routerReducer,
//   }),
//   {}, // initial state
// );

// describe('Test Mytable', () => {
//   before(() => {
//   });

//   it('setSort is working', () => {
//     expect(input.find('input')).to.have.length(1);
//   });
// });
