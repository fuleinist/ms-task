import PropTypes from 'prop-types';

export const proptypes = {
  showMyModal: PropTypes.bool,
  close: PropTypes.bool,
};

export const defaultprops = {
  showMyModal: false,
};
